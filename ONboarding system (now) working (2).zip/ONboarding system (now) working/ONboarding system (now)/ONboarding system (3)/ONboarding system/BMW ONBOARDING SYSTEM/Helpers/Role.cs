﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BMW_ONBOARDING_SYSTEM.Helpers
{
    public class Role
    {
        public const string Admin = "Admin";
        public const string Manager = "Manager";
        public const string Onboarder = "Onboarder";

    }
}
