﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BMW_ONBOARDING_SYSTEM.ViewModel
{
    public class LessonOutcomeViewModel
    {
       
        public string LessonOutcomeName { get; set; }
        public string LessonOutcomeDescription { get; set; }
        public int? LessonId { get; set; }
    }
}
