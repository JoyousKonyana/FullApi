﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BMW_ONBOARDING_SYSTEM.ViewModel
{
    public class NotificationViewModel
    {
        public int NotificationId { get; set; }
     
        public int NotificationTypeId { get; set; }
       
        public string NotificationMessageDescription { get; set; }
    }
}
