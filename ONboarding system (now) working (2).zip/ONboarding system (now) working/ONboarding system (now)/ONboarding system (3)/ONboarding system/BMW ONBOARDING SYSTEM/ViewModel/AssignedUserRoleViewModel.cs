﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BMW_ONBOARDING_SYSTEM.ViewModel
{
    public class AssignedUserRoleViewModel
    {
        public int User_ID { get; set; }
        public int UserRoleID { get; set; }
    }
}
