﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BMW_ONBOARDING_SYSTEM.ViewModel
{
    public class ProvinceViewModel
    {
        public int ProvinceId { get; set; }
       
        public string ProvinceName { get; set; }
    }
}
