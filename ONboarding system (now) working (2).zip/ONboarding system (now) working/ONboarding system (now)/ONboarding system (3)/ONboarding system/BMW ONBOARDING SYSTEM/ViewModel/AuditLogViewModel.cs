﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BMW_ONBOARDING_SYSTEM.ViewModel
{
    public class AuditLogViewModel
    {
        public DateTime startDate { get; set; }
        public DateTime endDate { get; set; }
    }
}
