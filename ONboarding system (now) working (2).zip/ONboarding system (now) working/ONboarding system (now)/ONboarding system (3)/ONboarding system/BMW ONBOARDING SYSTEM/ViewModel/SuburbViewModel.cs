﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BMW_ONBOARDING_SYSTEM.ViewModel
{
    public class SuburbViewModel
    {
        public int PostalCodeId { get; set; }
      
        public string SuburbName { get; set; }
    }
}
