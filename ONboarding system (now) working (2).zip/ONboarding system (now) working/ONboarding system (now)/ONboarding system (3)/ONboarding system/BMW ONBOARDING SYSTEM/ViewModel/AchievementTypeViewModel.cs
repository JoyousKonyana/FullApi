﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BMW_ONBOARDING_SYSTEM.ViewModel
{
    public class AchievementTypeViewModel
    {
        public int AchievementTypeId { get; set; }
        public string AchievementTypeDescription { get; set; }
        public int? BadgeId { get; set; }
    }
}
