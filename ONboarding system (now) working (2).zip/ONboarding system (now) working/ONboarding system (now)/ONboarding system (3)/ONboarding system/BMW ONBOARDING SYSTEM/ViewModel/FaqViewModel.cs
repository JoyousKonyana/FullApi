﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BMW_ONBOARDING_SYSTEM.ViewModel
{
    public class FaqViewModel
    {
        public int Faqid { get; set; }
        public string Faqdescription { get; set; }
        public string Faqanswer { get; set; }
    }
}
