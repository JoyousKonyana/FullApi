﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BMW_ONBOARDING_SYSTEM.ViewModel
{
    public class CourseViewModel
    {
        
        public string courseName { get; set; }

        public string courseDescription { get; set; }

        public DateTime? CourseDueDate { get; set; }
    }
}
