﻿using AutoMapper;
using BMW_ONBOARDING_SYSTEM.Interfaces;
using BMW_ONBOARDING_SYSTEM.Models;
using BMW_ONBOARDING_SYSTEM.Repositories;
using BMW_ONBOARDING_SYSTEM.ViewModel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BMW_ONBOARDING_SYSTEM.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LessonOutcomeController : ControllerBase
    {

        private readonly ILessonOutcome _lessonOutcomeRepository;
        private readonly IMapper _mapper;

        public LessonOutcomeController(ILessonOutcome lessonOutcomeRepository, IMapper mapper)
        {
            _lessonOutcomeRepository = lessonOutcomeRepository;
            _mapper = mapper;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var lessonOutcomes = await _lessonOutcomeRepository.GetAllLessonOutcomesAsync();
                return Ok(lessonOutcomes);
            }
            catch (Exception)
            {

                return BadRequest();
            }
        }


        [HttpGet("name")]
        public async Task<ActionResult<LessonOutcomeViewModel>> GetLessonOutcomeByName([FromBody] string name)
        {
            try
            {
                var result = await _lessonOutcomeRepository.GetLessonOutcomeByNameAsync(name);

                if (result == null) return NotFound();

                return _mapper.Map<LessonOutcomeViewModel>(result);
            }
            catch (Exception)
            {

                return this.StatusCode(StatusCodes.Status500InternalServerError, "Database failure");
            }
        }
        [HttpGet("{id}")]
        public async Task<ActionResult<LessonOutcomeViewModel>> GeLessonOutcomeByCourseId(int Courseid)
        {
            try
            {
                var result = await _lessonOutcomeRepository.GeLessonOutcomeByCourseId(Courseid);

                if (result == null) return NotFound();

                return _mapper.Map<LessonOutcomeViewModel>(result);
            }
            catch (Exception)
            {

                return this.StatusCode(StatusCodes.Status500InternalServerError, "Database failure");
            }
        }

        [HttpPost]
        public async Task<ActionResult<LessonOutcomeViewModel>> CreateLessonOutcome([FromBody] LessonOutcomeViewModel model)
        {
            try
            {
                var lessonOutcome = _mapper.Map<LessonOutcome>(model);
                _lessonOutcomeRepository.Add(lessonOutcome);

                if (await _lessonOutcomeRepository.SaveChangesAsync())
                {
                    return Created($"/api/LessonOutcome{lessonOutcome.LessonOutcomeName}", _mapper.Map<LessonOutcomeViewModel>(lessonOutcome));
                }
            }
            catch (Exception)
            {

                BadRequest();
            }
            return BadRequest();
        }



        // This method is only accessable by members with admin access level
        [HttpPut("name")]

        public async Task<ActionResult<LessonOutcomeViewModel>> Put(string name, LessonOutcomeViewModel updatedCourseModel)
        {
            try
            {
                var existingLessonOutcome = await _lessonOutcomeRepository.GetLessonOutcomeByNameAsync(name);

                if (existingLessonOutcome == null) return NotFound($"Could Not find course with the name: {name }");

                _mapper.Map(updatedCourseModel, existingLessonOutcome);

                if (await _lessonOutcomeRepository.SaveChangesAsync())
                {
                    return _mapper.Map<LessonOutcomeViewModel>(existingLessonOutcome);
                }
            }
            catch (Exception)
            {

                return this.StatusCode(StatusCodes.Status500InternalServerError, "Database Failure");
            }

            return BadRequest();

        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                var existingLessonOutcome = await _lessonOutcomeRepository.GetLessonOutcomeIdAsync(id);

                if (existingLessonOutcome == null) return NotFound();

                _lessonOutcomeRepository.Delete(existingLessonOutcome);

                if (await _lessonOutcomeRepository.SaveChangesAsync())
                {
                    return Ok();
                }
            }
            catch (Exception)
            {

                return this.StatusCode(StatusCodes.Status500InternalServerError, $"We could not delete this lesson outcome");
            }

            return BadRequest();
        }


    }
}
